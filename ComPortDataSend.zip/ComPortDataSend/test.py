import os
import time

import requests
import serial
import win32api
import win32print
from pyhtml2pdf import converter

port = os.getenv("COM")


class Data:
    def __init__(self, platform=None, product=None):
        self.platform = platform
        self.product = product


data = Data(platform=10, product=None)

response = requests.post(f"http://{os.getenv("IP_AND_PORT")}/api/sp_data", json=data.__dict__)
